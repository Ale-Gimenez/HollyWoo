//const API_URL = import.meta.env.VITE_API_URL;

export async function getMovies(){
    const response = await fetch("/data/filmes.json");
    if(!response.ok){
        throw new Error("nao conseguiu obter os filmes");
    }
    return response.json();
}

