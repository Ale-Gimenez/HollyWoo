export default function Imagens() {
    return (
        <section className="imagem">
            <h2>Imagem</h2>
            <img src="https://static0.srcdn.com/wordpress/wp-content/uploads/2019/08/Jack-Sparrow-cannibal-chase-Pirates-Caribbean.jpeg?q=50&fit=crop&w=1312&h=902&dpr=1.5" alt="Jack Sparrow" />
        </section>
    )
}