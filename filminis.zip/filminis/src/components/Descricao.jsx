export default function Descricao() {

    return (
    <section className="descricao">
      <h2>descrição</h2>
      <p>Jack Sparrow é um pirata famoso, conhecido por sua astúcia e liberdade.</p>
      <p>Que em primeiro momento era um personagem coadjuvante.</p>
    </section>
    )
}
