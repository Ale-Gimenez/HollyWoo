
export default function Header() {

    return (
    <header>
        <h1>Perfil</h1>
        <h2>Jack Sparrow</h2>
      </header>
    )

}