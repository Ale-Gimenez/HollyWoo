export default function Hobbies() {

    return (
    <section className="hobbies">
      <h2>Hobbies e poderes</h2>
      <ul>
        <li>Navegar pelos mares</li>
        <li>Combate com espada</li>
        <li>Fuga rápida</li>
      </ul>
    </section>
    )
}