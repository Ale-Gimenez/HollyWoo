import { useState, useEffect } from 'react'
import '../App.css'

function MoviesList() {
  const [filmes, setFilmes] = useState([])
  const [erro, setErro] = useState(null)

  useEffect(() => {
    fetch('/data/filmes.json')
      .then((res) => {
        if (!res.ok) throw new Error('Não foi possível carregar filmes')
        return res.json()
      })
      .then((data) => setFilmes(data))
      .catch((error) => setErro(error.message))
  }, [])

  return (
    <div className="Container">
      <header className="topo">
        <h1>Filminis</h1>
        <p>Sua plataforma favorita de filmes</p>
      </header>

      {erro && <div className="erro">{erro}</div>}

      {filmes.length === 0 && !erro ? (
        <p className="loading">Carregando filmes...</p>
      ) : (
        <div className="filmes-grid">
          {filmes.map((filme) => (
            <article key={filme.id} className="filme-card">
              <img className="filme-poster" src={filme.poster} alt={filme.titulo} />
              <div className="filme-info">
                <h3>{filme.titulo}</h3>
                <p className="subtitulo">{filme.ano} · {filme.duracao}</p>
                <p className="categorias">{filme.categorias.join(', ')}</p>
                <p className="detalhes">
                  <strong>Direção:</strong> {filme.diretores.join(', ')}
                </p>
                <p className="detalhes">
                  <strong>Atores:</strong> {filme.atores.slice(0, 3).join(', ')}
                </p>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  )
}

export default MoviesList