export default function Preferencia() {
    return (
    <section className="preferencia">
      <h2>Preferência</h2>
      <p>Jack Sparrow é um personagem intrigante e cheio de personalidade, o que o torna um dos meus favoritos.</p>
    </section>
    )
}