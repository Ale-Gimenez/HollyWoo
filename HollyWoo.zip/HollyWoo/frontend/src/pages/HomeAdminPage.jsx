import { useNavigate } from 'react-router-dom'
import { useFilmes } from '../context/FilmesContext'
import FilmCard from '../components/FilmCard'
import '../styles/Pages.css'
import '../styles/Shared.css'

export default function HomeAdminPage() {
  const { filmes } = useFilmes()
  const navigate = useNavigate()
  const recentes = filmes.slice(0, 6)

  return (
    <main className="home-admin">
      <div className="home-admin-inner">
        {/* Banner */}
        <section className="home-admin-banner">
          <div className="home-admin-welcome">
            <h1>Seja Bem-Vindo<br />Administrador :)</h1>
            <div className="home-admin-welcome-btns">
              <button className="btn btn-primary" onClick={() => navigate('/adicionar')}>
                + Adicionar Filme
              </button>
              <button className="btn btn-suggest" onClick={() => navigate('/sugestoes')}>
                🚀 Sugestões
              </button>
            </div>
          </div>

          <div className="home-admin-mascot">
            <div className="home-admin-bubble">
              <p className="home-admin-bubble-emoji">😊</p>
              <p>"Sem você nada disto seria possível, agradecemos todo o tempo dedicado a oferecer entretenimento às crianças por meio da inserção de filmes."</p>
              <p className="home-admin-bubble-att">Att. HollyWoozinho</p>
            </div>
            {/* Mascote SVG */}
            <svg width="120" height="130" viewBox="0 0 120 130" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
              <rect x="30" y="40" width="60" height="65" rx="12" fill="#7833e2"/>
              <rect x="35" y="15" width="50" height="35" rx="8" fill="#9655f5"/>
              <rect x="30" y="10" width="12" height="10" rx="3" fill="#b693ec" transform="rotate(-15 30 10)"/>
              <rect x="78" y="10" width="12" height="10" rx="3" fill="#b693ec" transform="rotate(15 78 10)"/>
              <circle cx="47" cy="32" r="7" fill="white"/>
              <circle cx="73" cy="32" r="7" fill="white"/>
              <circle cx="47" cy="32" r="4" fill="#1a1a1a"/>
              <circle cx="73" cy="32" r="4" fill="#1a1a1a"/>
              <circle cx="49" cy="30" r="1.5" fill="white"/>
              <circle cx="75" cy="30" r="1.5" fill="white"/>
            </svg>
          </div>
        </section>

        {/* Recent films */}
        <section aria-labelledby="ultimos-title">
          <h2 id="ultimos-title" className="section-title">Últimos Filmes Adicionados</h2>
          <div className="home-admin-films-grid">
            {recentes.map(f => <FilmCard key={f.id} filme={f} showInfo={false} />)}
          </div>
        </section>
      </div>
    </main>
  )
}
